package co.edu.unab.citasuitg62;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Citasuitg62ApplicationTests {

	@Test
	void contextLoads() {
	}

}
